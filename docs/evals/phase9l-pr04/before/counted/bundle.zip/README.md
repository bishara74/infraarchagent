# InfraArchAgent — all three variants

Run ID: 00000000-0000-4000-8000-000000000704

| Variant | Readiness label | Individual ZIP | SHA-256 |
|---|---|---|---|
| cost | engineer_approved | infraarch-00000000-cost-engineer_approved.zip | 354994f98559d7c11cf43b41d6ea39ff4d6eed04e3ccfade5e33d4ac3baea25b |
| performance | checks_passed | infraarch-00000000-performance-checks_passed.zip | abdbdd657f8b482e682eb3aedf0003912de36e5f2d47f80e88798b49b171ba3a |
| security | rejected | infraarch-00000000-security-rejected.zip | 0a5c467b3e01d715544c0b710458852995e6dc076ea0b62f0c2dbf6faafa8603 |

Each variant folder contains exactly its individual download's payload, including its readiness document. Labels describe static checks and engineer decisions, not a deployment.

manifest.json lists the SHA-256 of every included file except itself, including this README. Compare individual ZIP hashes only for the same run and unchanged readiness snapshot. No manifest can hash itself.
