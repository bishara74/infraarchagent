# InfraArchAgent — all three variants

Run ID: 00000000-0000-4000-8000-000000000704

| Variant | Readiness label | Individual ZIP | SHA-256 |
|---|---|---|---|
| cost | engineer_approved | infraarch-00000000-cost-engineer_approved.zip | b04677b3cb2bd26fe817584e47e789a10c97572da1b35c442b5b6d396df8dc72 |
| performance | checks_passed | infraarch-00000000-performance-checks_passed.zip | 358337f26a195c82f7840b68e792617e85f7a54007c61bacedfdad0608e87c19 |
| security | rejected | infraarch-00000000-security-rejected.zip | 8812b4185c79c20db3819287b95027c822baf1907c74add10a8dbe36757e67ea |

Each variant folder contains exactly its individual download's payload, including its readiness document. Labels describe static checks and engineer decisions, not a deployment.

manifest.json lists the SHA-256 of every included file except itself, including this README. Compare individual ZIP hashes only for the same run and unchanged readiness snapshot. No manifest can hash itself.
