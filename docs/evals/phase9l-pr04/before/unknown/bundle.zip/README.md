# InfraArchAgent — all three variants

Run ID: 00000000-0000-4000-8000-000000000704

| Variant | Readiness label | Individual ZIP | SHA-256 |
|---|---|---|---|
| cost | engineer_approved | infraarch-00000000-cost-engineer_approved.zip | 4bfd58e239b6313ca88f305e6ce2ab19eb2e49a445c4930f74e9863f551a22d1 |
| performance | checks_passed | infraarch-00000000-performance-checks_passed.zip | bf9ee21bb2e63381597d28fbb8d3dc5d4c12fd3a20c9f88c6cfbe547d66443a3 |
| security | rejected | infraarch-00000000-security-rejected.zip | 36d72d286d54b7fd24d8f66bdd675c238ac6483bc830848a23f75b3b64365118 |

Each variant folder contains exactly its individual download's payload, including its readiness document. Labels describe static checks and engineer decisions, not a deployment.

manifest.json lists the SHA-256 of every included file except itself, including this README. Compare individual ZIP hashes only for the same run and unchanged readiness snapshot. No manifest can hash itself.
