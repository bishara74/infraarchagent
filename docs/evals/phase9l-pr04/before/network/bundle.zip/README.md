# InfraArchAgent — all three variants

Run ID: 00000000-0000-4000-8000-000000000704

| Variant | Readiness label | Individual ZIP | SHA-256 |
|---|---|---|---|
| cost | engineer_approved | infraarch-00000000-cost-engineer_approved.zip | 2b60cd4fc668baf649a19d5eb6cf6da32279574b48036e176a9944347693ae29 |
| performance | checks_passed | infraarch-00000000-performance-checks_passed.zip | bc093d1c525a339fbf433caac113cea11c13db004410f43a5ff2ff65a6afdc27 |
| security | rejected | infraarch-00000000-security-rejected.zip | 5e8c953729cd5438791739e760615f14abe2be526d809e8829f9b502918c61d1 |

Each variant folder contains exactly its individual download's payload, including its readiness document. Labels describe static checks and engineer decisions, not a deployment.

manifest.json lists the SHA-256 of every included file except itself, including this README. Compare individual ZIP hashes only for the same run and unchanged readiness snapshot. No manifest can hash itself.
