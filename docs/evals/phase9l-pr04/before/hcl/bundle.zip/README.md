# InfraArchAgent — all three variants

Run ID: 00000000-0000-4000-8000-000000000704

| Variant | Readiness label | Individual ZIP | SHA-256 |
|---|---|---|---|
| cost | engineer_approved | infraarch-00000000-cost-engineer_approved.zip | c5aa01fa2e693cc62a5ea95e3bce1b994760eef73d0eb72067cb018ea0dfd0ed |
| performance | checks_passed | infraarch-00000000-performance-checks_passed.zip | be32e46a658804ab772c89c38fcb533020d58a00cf4598ab1408b8a9c568f676 |
| security | rejected | infraarch-00000000-security-rejected.zip | c6d9dea264ed42d014931ed3a736b5ff37915acbe056f18a51b7e224776d7264 |

Each variant folder contains exactly its individual download's payload, including its readiness document. Labels describe static checks and engineer decisions, not a deployment.

manifest.json lists the SHA-256 of every included file except itself, including this README. Compare individual ZIP hashes only for the same run and unchanged readiness snapshot. No manifest can hash itself.
