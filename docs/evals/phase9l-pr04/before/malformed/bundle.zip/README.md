# InfraArchAgent — all three variants

Run ID: 00000000-0000-4000-8000-000000000704

| Variant | Readiness label | Individual ZIP | SHA-256 |
|---|---|---|---|
| cost | engineer_approved | infraarch-00000000-cost-engineer_approved.zip | 5b91a55bfcc122b3d5fe818266840a8e9ffaf8bce742b8672ed74be6f8a54786 |
| performance | checks_passed | infraarch-00000000-performance-checks_passed.zip | 488f49f52c1220d8d579fe9e352692b9239018fb50d39fc6a6062ce599743ef7 |
| security | rejected | infraarch-00000000-security-rejected.zip | 92e33d9a5d052dd9e8226ee18e1e72796e54b633bdabe14115019113994bcf58 |

Each variant folder contains exactly its individual download's payload, including its readiness document. Labels describe static checks and engineer decisions, not a deployment.

manifest.json lists the SHA-256 of every included file except itself, including this README. Compare individual ZIP hashes only for the same run and unchanged readiness snapshot. No manifest can hash itself.
